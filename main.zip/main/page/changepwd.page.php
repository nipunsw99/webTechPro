<?php
session_start();
include_once("../include/connection.include.php");
?>

<?php
if (isset($_SESSION['admins'])) {
    ?>
<form action="changepwd.page.php" method="post">
    <div><input type="password" placeholder="Current password" name="currPwd"></div><br>
    <div><input type="password" placeholder="New password" name="newPwd"></div>
    <div><input type="password" placeholder="Confirm password" name="newConPwd"></div>
    <div><button type="submit" name="cPwd">Change password</button></div>
    <div><button type="submit" name="goback">Go back</button></div>
</form>
<?php
    if (isset($_POST['goback'])) {
        echo "<script>";
        echo "window.location.href = 'admin.page.php';";
        echo "</script>";
    }

    if (isset($_POST['cPwd'])) {
        $curr = $_POST['currPwd'];
        $adm = $_SESSION['admins'];
        $sql = "SELECT adminpwd FROM admin_base WHERE admins = '$adm';";
        $result = mysqli_query($con, $sql);
        $row = mysqli_fetch_assoc($result);
        if (password_verify($curr, $row['adminpwd'])) {
            $newPwd = password_hash($_POST['newPwd'], PASSWORD_DEFAULT);
            $newConPwd = password_hash($_POST['newConPwd'], PASSWORD_DEFAULT);
            if ($_POST['newPwd'] == $_POST['newConPwd']) {
                $sql = "UPDATE admin_base SET adminpwd = '$newPwd' WHERE admins = '$adm';";
                $result = mysqli_query($con, $sql);
                if ($result) {
                    $_SESSION['admins'] = $adm;
                    echo "<script>alert('Password changed successfully');window.location.href='admin.page.php';</script>";
                    updateHistory($con, "Admin changed admin password.");
                    // echo "<a href="admin.page.php"></a>";
                } else {
                    echo "<script>alert('Something went wrong');window.location.href='changepwd.page.php';</script>";
                }
            } else {
                echo "<script>alert('Passwords do not match');window.location.href='changepwd.page.php';</script>";
            }
        } else {
            echo "<script>alert('Invalid password');window.location.href='changepwd.page.php';</script>";
        }


    }

} else if (isset($_SESSION['regNum'])) {
    if (isset($_POST['cPwd'])) {
        $curr = $_POST['currPwd'];
        $adm = $_SESSION['regNum'];
        $sql = "SELECT password FROM user_details WHERE regNum = '$adm';";
        $result = mysqli_query($con, $sql);
        $row = mysqli_fetch_assoc($result);
        if (password_verify($curr, $row['adminpwd'])) {
            $newPwd = password_hash($_POST['newPwd'], PASSWORD_DEFAULT);
            $newConPwd = password_hash($_POST['newConPwd'], PASSWORD_DEFAULT);
            if ($_POST['newPwd'] == $_POST['newConPwd']) {
                $sql = "UPDATE user_details SET password = '$newPwd' WHERE regNum = '$adm';";
                $result = mysqli_query($con, $sql);
                if ($result) {
                    $_SESSION['regNum'] = $adm;
                    echo "<script>alert('Password changed successfully');window.location.href='okay.html';</script>";
                    updateHistory($con, $adm . " changed password.");
                } else {
                    echo "<script>alert('Something went wrong');window.location.href='changepwd.page.php';</script>";
                }
            } else {
                echo "<script>alert('Passwords do not match');window.location.href='changepwd.page.php';</script>";
            }
        } else {
            echo "<script>alert('Invalid password');window.location.href='changepwd.page.php';</script>";
        }


    }
} else {
    session_destroy();
    header("location:index.php");
}
?>