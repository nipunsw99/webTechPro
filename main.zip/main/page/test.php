<?php
$str = "CSC201S3";
echo $str[3];
echo $str[strlen($str)-2];

?>