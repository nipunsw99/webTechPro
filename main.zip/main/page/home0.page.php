<?php
session_start();
include_once("../include/connection.include.php");
include_once("../style/home.style.php");
if (isset($_SESSION['regNum']) || isset($_SESSION['admins'])) {
    ?>
    <div class="upper">
        <div class="logo">
            <div>
                <img src="../media/kuppi logo.png" alt="">
            </div>
        </div>
        <div class="header">
            <div class="head1">
                <div class="nav"><a class="nava" href="profile.page.php">Profile</a></div>
                <div class="nav"><a class="nava" href="">Analysis</a></div>
                <div class="nav"><a class="nava" href="">About us</a></div>
                <div class="nav profileicon">
                    <div class="profilepic"><img src="../media/profile_default.png" alt=""></div>
                    <div>
                        <?php if (isset($_SESSION['admins'])) {
                            echo $_SESSION['admins'];
                        } else {
                            echo $_SESSION['regNum'];
                        } ?>
                    </div>
                </div>
            </div>
        </div>
        <div class="head2">
            <div>Search</div>
            <div><input type="text" placeholder="Search"></div>
        </div>
    </div>

    <div class="get-help">
        <?php
        $sql = "SELECT user_details.regNum, user_details.fName, user_details.lName, user_details.degree, user_details.telephone, user_details.email, user_details.gender,get_kuppi_details.GKid, gender,get_kuppi_details.getcoz, gender,get_kuppi_details.gettitle, gender,get_kuppi_details.getdesc FROM user_details INNER JOIN get_kuppi_details ON user_details.regNum=get_kuppi_details.regNum;";
        $result = mysqli_query($con, $sql);
        while ($row = mysqli_fetch_assoc($result)) { ?>
            <div>
                <div>
                    <!--image-->
                </div>
                <div>
                    <div>
                        <?php echo $row['gettitle']; ?>
                    </div>
                    <div>
                        <?php echo $row['getcoz']; ?>
                    </div>
                    <div>
                        <?php echo $row['fName'] . " " . $row['lName'] ?>
                    </div>
                    <div>
                        <?php
                        $gender = $row['gender'];
                        if ($gender == "male") {
                            $gender = "<i class='bx bx-male'></i>";
                        } else {
                            $gender = "<i class='bx bx-female'></i>";
                        }
                        echo $gender;
                        ?>
                    </div>
                    <div>
                        <?php if ($row['degree'] == "dcs") {
                            echo "Direct Computer Science";
                        } else {
                            echo "Physical Computer Science";
                        } ?>
                    </div>
                    <div>
                        <form action="home.page.php" method="post">
                            <input type="hidden" value="get" name="visittype">
                            <div><button value="<?php
                            echo $row['GKid']; ?>" type="submit" name="visit">Visit</button></div>
                        </form>
                    </div>
                </div>
            </div>
        <?php }
        ?>
    </div>

    <div class="get-help">
        <?php
        $sql = "SELECT user_details.regNum, user_details.fName, user_details.lName, user_details.degree, user_details.telephone, user_details.email, user_details.gender,give_kuppi_details.GKid, gender,give_kuppi_details.kuppicoz, gender,give_kuppi_details.kuppititle, gender,give_kuppi_details.kuppidesc FROM user_details INNER JOIN give_kuppi_details ON user_details.regNum=give_kuppi_details.regNum;";
        $result = mysqli_query($con, $sql);
        while ($row = mysqli_fetch_assoc($result)) { ?>
            <div>
                <div>
                    <!--image-->
                </div>
                <div>
                    <div>
                        <?php echo $row['kuppititle']; ?>
                    </div>
                    <div>
                        <?php echo $row['kuppicoz']; ?>
                    </div>
                    <div>
                        <?php echo $row['fName'] . " " . $row['lName'] ?>
                    </div>
                    <div>
                        <?php
                        $gender = $row['gender'];
                        if ($gender == "male") {
                            $gender = "<i class='bx bx-male'></i>";
                        } else {
                            $gender = "<i class='bx bx-female'></i>";
                        }
                        echo $gender;
                        ?>
                    </div>
                    <div>
                        <?php if ($row['degree'] == "dcs") {
                            echo "Direct Computer Science";
                        } else {
                            echo "Physical Computer Science";
                        } ?>
                    </div>
                    <div>
                        <form action="home.page.php" method="post">
                            <input type="hidden" value="give" name="visittype">
                            <div><button value="<?php
                            echo $row['GKid']; ?>" type="submit" name="visit">Visit</button></div>
                        </form>
                    </div>
                </div>
            </div>
        <?php }
        ?>
    </div>

    <?php

    if (isset($_POST['visit'])) {
        $_SESSION['GKid'] = $_POST['visit'];
        if (($_POST['visittype'] == "give")) {
            $_SESSION['Kuppitype'] = $_POST['visittype'];
        }
        if (($_POST['visittype'] == "get")) {
            $_SESSION['Kuppitype'] = $_POST['visittype'];
        }
        echo "<script>";
        echo "window.location.href = 'postview.page.php';";
        echo "</script>";
    }
} else {
    header("Location:index.php");
    exit();
}
?>