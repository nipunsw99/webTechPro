<?php
include_once("../include/connection.include.php");
$p = 10;
$t = 160;
?>
<style>
    .red {
        width: 800px;
        background: red;
        height: 50px;
    }

    .green {
        width:
            <?php echo $p;
            ?>
            %;
        height: 50px;
        background: green;
    }
</style>
<div class="red">
    <div class="green">
        <?php echo $p . "%"; ?>
    </div>
</div>