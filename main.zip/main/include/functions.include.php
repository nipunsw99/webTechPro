<?php
include_once("connection.include.php");

function isEmpty($regNum, $fName, $lName, $degree, $telephone, $email, $password, $rePassword, $adminKey, $gender)
{
    if (empty($gender) || empty($regNum) || empty($fName) || empty($lName) || empty($degree) || empty($telephone) || empty($email) || empty($password) || empty($rePassword) || empty($adminKey)) {
        return true;
    } else {
        return false;
    }
}

// function isMatch($password,$rePassword){
//     if($password === $rePassword){
//         return false;
//     }
//     else{
//         return true;
//     }
// }

function isValidEnrollment($con, $adminKey)
{
    $sql = "SELECT enrollkey FROM admin_base WHERE Aid=1;";
    $result = mysqli_query($con, $sql);
    $row = mysqli_fetch_assoc($result);
    if ($adminKey === $row['enrollkey']) {
        return false;
    } else {
        return true;
    }
}


function isValidPhone($telephone)
{
    $pattern = '/^[0-9]{10}$/';
    return preg_match($pattern, $telephone);
}

// function isValidEmail($email){
//     $pattern = '/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,4})$/';
//     return preg_match($pattern,$email);
// }

function isValidNames($fName, $lName)
{
    $fName = trim($fName);
    $lName = trim($lName);
    $pattern = '/^[a-zA-Z]+$/';
    return preg_match($pattern, $fName) && preg_match($pattern, $lName);
}

function isValidReg($regNum)
{
    $pattern = '/^\d{4}(?:[cC][sS][cC]|[sS][pP])\d{3}$/';


    if (preg_match($pattern, $regNum)) {
        return false;
    } else {
        return true;
    }

}

function insertToDatabase($con, $fName, $lName, $regNum, $degree, $gender, $password, $telephone, $email)
{
    $sql = "INSERT INTO user_details (regNum,fName,lName,degree,gender,password,telephone,email) VALUES ('$regNum','$fName','$lName','$degree','$gender','$password','$telephone','$email');";
    $result = mysqli_query($con, $sql);
    if ($result) {
        echo "<script>";
        echo "window.location.href = '../page/index.php';";
        echo "</script>";
    } else {
        echo "<script>";
        echo "window.location.href = '../page/signup.php';";
        echo "</script>";
    }
}

function isExistReg($con, $loginName, $loginPassword)
{
    $sql = "SELECT password FROM user_details WHERE regNum='$loginName';";
    $result = mysqli_query($con, $sql);
    if ($result) {
        $row = mysqli_fetch_assoc($result);
        if (password_verify($loginPassword, $row['password'])) {
            return false;
        } else {
            return true;
        }
    } else {
        return true;
    }
}

function isAdmin($con, $loginName, $loginPassword)
{
    $sql = "SELECT * FROM admin_base WHERE Aid=1;";
    $result = mysqli_query($con, $sql);
    $row = mysqli_fetch_assoc($result);
    if ($loginName == $row['admins'] && password_verify($loginPassword, $row['adminpwd'])) {
        return true;
    } else {
        return false;
    }
}


function isMode($con, $loginName, $loginPassword)
{
    $sql = "SELECT * FROM admin_base WHERE admins='$loginName' AND Aid != 1;";
    $result = mysqli_query($con, $sql);

    if ($result && mysqli_num_rows($result) > 0) {
        // There are results, fetch the row
        $row = mysqli_fetch_assoc($result);

        if ($loginName == $row['admins'] && password_verify($loginPassword, $row['adminpwd'])) {
            return true;
        }
    }

    return false;
}