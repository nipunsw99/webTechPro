<style>
* {
    padding: 0;
    margin: 0;
    box-sizing: border-box;
}

.s-man {
    display: flex;
    flex-direction: row;
    width: 100%;
}

.def-coz {
    display: flex;
    flex-direction: column;
    margin: 1%;
    background: rgb(182, 182, 182);
    justify-content: center;
    align-items: center;
    width: 30%;
}


.a-coz div {}

.d-coz {}

.s-man-btn {
    margin: 5px;
    transition: 0.5s;
    border: none;
}

.s-man-btn:hover {
    background: aqua;
    border: none;
}
</style>

<style>
.l-coz{
    width: 50%;
    background: rgb(6, 218, 218);
    display: flex;
    flex-direction: column;
    padding: 5px;
    font-size: 20px;
}
.l-coz-head{
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: left;
}
.l-coz-head-2{
    display: flex;
    flex-direction: row;
    justify-content: center;
    align-items: center;
}
.l-coz-body{
    background: red;
}
.l-coz-body-c{
    display: flex;
    flex-direction: column;
}
.l-coz-body-c-in{
    display: flex;
    flex-direction: row;
    justify-content: center;
    align-items: center;
}
.l-coz-body-c-in div{
width: 400px;
}

</style>