<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>
    * {
        padding: 0;
        margin: 0;
        box-sizing: border-box;
    }

    .kuppi-div {
        display: flex;
        justify-content: center;
        align-items: center;
        width: 100%;
        height: 100%;
    }

    .kuppi {
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        width: 40%;
        height: 60%;
        border: 5px solid rgb(0, 74, 87);
        border-radius: 20px;
    }

    .dd {
        margin: 2%;
        font-size: 50px;
        display: flex;
        justify-content: center;
        align-items: center;
        width: 100%;
    }

    .dd input {
        font-size: 20px;
        border: 5px solid rgb(0, 74, 87);
    }

    .dd textarea {
        font-size: 15px;
        border: 5px solid rgb(0, 74, 87);
    }

    #list-sub {
        font-size: 30px;
        border: 5px solid rgb(0, 74, 87);
        cursor: pointer;
    }

    #kuppicoz {
        width: 60%;
        font-size: 15px;
        border: 5px solid rgb(0, 74, 87);
        cursor: pointer;
    }

    .dd button {
        width: 50%;
        height: 50px;
        background: rgb(0, 74, 87);
        color: #fff;
        border: none;
        transition: 0.2s;
        font-size: large;
        font-weight: bold;
        border-radius: 10px;
        cursor: pointer;
    }

    .dd button:hover {
        scale: 105%;
        background: #fff;
        color: black;
        border: 1px solid rgb(0, 74, 87);
        box-shadow: 0 0 10px rgb(0, 74, 87);
        border-radius: 10px;
    }
</style>
<style>
    @media only screen and (max-width: 768px) {
        .kuppi-div {
            display: flex;
            justify-content: center;
            align-items: center;
            width: 100%;
            height: 100%;

        }

        .kuppi {
            width: 80%;
            height: 50%;
        }

        .dd {
            font-size: 25px;
        }
    }
</style>