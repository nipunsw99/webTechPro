-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 31, 2023 at 01:24 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.1.17

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `main`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_base`
--

CREATE TABLE `admin_base` (
  `Aid` int(32) NOT NULL,
  `admins` varchar(128) NOT NULL,
  `adminpwd` varchar(128) NOT NULL,
  `enrollkey` varchar(128) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin_base`
--

INSERT INTO `admin_base` (`Aid`, `admins`, `adminpwd`, `enrollkey`) VALUES
(1, 'admin039', '$2y$10$tlTTWzJj0pExCvy/trohhu3m6gnouw0oGM1G5o.zQnkYa/k0UpUXy', '1122'),
(4, 'moderate039Thili', '$2y$10$DKOQr4AjFzkyxscOfHOLruYq6nS1TevBftIT7vyEfeAJSFZLAuw3S', 'CSC039'),
(5, 'moderate039ks', '$2y$10$KqTiq3OSTy1VdH4WsRzvwuCMxQLK.b4gf0MgMWZESMvQ.MMaiP6ra', 'CSC039');

-- --------------------------------------------------------

--
-- Table structure for table `coz_details`
--

CREATE TABLE `coz_details` (
  `id` int(32) NOT NULL,
  `cozid` varchar(32) NOT NULL,
  `cozname` varchar(128) NOT NULL,
  `cozlevel` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `coz_details`
--

INSERT INTO `coz_details` (`id`, `cozid`, `cozname`, `cozlevel`) VALUES
(16, 'CSC103S3', 'Introduction to Computer Systems', 'Level 1S'),
(17, 'CSC104S2', 'Mathematics for Computing I', 'Level 1S'),
(18, 'CSC105S3', 'Statistics for Computing I', 'Level 1S'),
(19, 'CSC106S3', 'Human Computer Interaction', 'Level 1S'),
(20, 'CSC107S2', 'Multimedia Technologies', 'Level 1S'),
(21, 'CSC108S2', 'Design of Algorithms', 'Level 1S'),
(22, 'CSC109S2', 'Introduction to Computer Security and Cryptography', 'Level 1S'),
(23, 'CSC110S2', 'Organisational Behaviour', 'Level 1S'),
(24, 'CSC111S2', 'Mathematics for Computing II', 'Level 1S'),
(25, 'CSC112S3', 'Statistics for Computing II', 'Level 1S'),
(26, 'CSC101S3', 'Foundations of Computer Science', 'Level 1S'),
(27, 'CSC102S3', 'Computer Programming I', 'Level 1S');

-- --------------------------------------------------------

--
-- Table structure for table `get_kuppi_details`
--

CREATE TABLE `get_kuppi_details` (
  `GKid` int(11) NOT NULL,
  `regNum` varchar(32) NOT NULL,
  `getcoz` varchar(128) NOT NULL,
  `gettitle` varchar(512) NOT NULL,
  `getdesc` varchar(2048) NOT NULL,
  `getkey` varchar(2048) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `give_kuppi_details`
--

CREATE TABLE `give_kuppi_details` (
  `GKid` int(11) NOT NULL,
  `regNum` varchar(32) NOT NULL,
  `kuppicoz` varchar(128) NOT NULL,
  `kuppititle` varchar(512) NOT NULL,
  `kuppidesc` varchar(2048) NOT NULL,
  `getkey` varchar(2048) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `give_kuppi_details`
--

INSERT INTO `give_kuppi_details` (`GKid`, `regNum`, `kuppicoz`, `kuppititle`, `kuppidesc`, `getkey`) VALUES
(8, '2020csc039', 'CSC108S2', 'I like to share my knowledge!', 'I got A+ grade for this subject so, I like to share my knowledge with you', 'algorithm');

-- --------------------------------------------------------

--
-- Table structure for table `history`
--

CREATE TABLE `history` (
  `id` int(11) NOT NULL,
  `descr` varchar(600) DEFAULT NULL,
  `dt` date DEFAULT NULL,
  `tm` time DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `history_main`
--

CREATE TABLE `history_main` (
  `id` int(11) NOT NULL,
  `descr` varchar(600) DEFAULT NULL,
  `dt` date DEFAULT NULL,
  `tm` time DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `user_details`
--

CREATE TABLE `user_details` (
  `regNum` varchar(32) NOT NULL,
  `fName` varchar(128) NOT NULL,
  `lName` varchar(128) NOT NULL,
  `degree` varchar(32) NOT NULL,
  `gender` varchar(16) NOT NULL,
  `password` varchar(512) NOT NULL,
  `telephone` varchar(16) NOT NULL,
  `email` varchar(32) NOT NULL,
  `img` varchar(1024) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_details`
--

INSERT INTO `user_details` (`regNum`, `fName`, `lName`, `degree`, `gender`, `password`, `telephone`, `email`, `img`) VALUES
('2020csc039', 'Nipun', 'Weerasinghe', 'dcs', 'male', '$2y$10$xwK5IBuhbfBdUqhIIR.9lOImV6jrkh7Bz1bM7A4/UHnezOlaAxjh.', '0719941670', 'nipunsw1999@gmail.com', '64f0696002ad4.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_base`
--
ALTER TABLE `admin_base`
  ADD PRIMARY KEY (`Aid`);

--
-- Indexes for table `coz_details`
--
ALTER TABLE `coz_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `get_kuppi_details`
--
ALTER TABLE `get_kuppi_details`
  ADD PRIMARY KEY (`GKid`),
  ADD KEY `FK_user_detailsget_kuppi_details` (`regNum`);

--
-- Indexes for table `give_kuppi_details`
--
ALTER TABLE `give_kuppi_details`
  ADD PRIMARY KEY (`GKid`),
  ADD KEY `FK_user_detailsgive_kuppi_details` (`regNum`);

--
-- Indexes for table `history`
--
ALTER TABLE `history`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `history_main`
--
ALTER TABLE `history_main`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_details`
--
ALTER TABLE `user_details`
  ADD PRIMARY KEY (`regNum`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_base`
--
ALTER TABLE `admin_base`
  MODIFY `Aid` int(32) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `coz_details`
--
ALTER TABLE `coz_details`
  MODIFY `id` int(32) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `get_kuppi_details`
--
ALTER TABLE `get_kuppi_details`
  MODIFY `GKid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `give_kuppi_details`
--
ALTER TABLE `give_kuppi_details`
  MODIFY `GKid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `history`
--
ALTER TABLE `history`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT for table `history_main`
--
ALTER TABLE `history_main`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
