<?php
echo "<script>";
echo "window.location.href = 'page/index.php';";
echo "</script>";
?>